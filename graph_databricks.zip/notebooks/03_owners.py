# Databricks notebook source
# MAGIC %md
# MAGIC # 03_owners — `/groups/{id}/owners` (Unity Catalog)

# COMMAND ----------
%run ./00_shared_utils

# COMMAND ----------
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from pyspark.sql import functions as F

try:
    dbutils.widgets.text("max_parallel", "24")
    dbutils.widgets.text("run_id", "owners-0")
    dbutils.widgets.text("mode", "delta")
except Exception:
    pass

MAX_PARALLEL = int(dbutils.widgets.get("max_parallel")) if 'dbutils' in globals() else 24
RUN_ID = dbutils.widgets.get("run_id") if 'dbutils' in globals() else f"owners-{int(datetime.now().timestamp())}"
MODE = dbutils.widgets.get("mode") if 'dbutils' in globals() else "delta"
DB = f"{UC_CATALOG}.{UC_SCHEMA}"

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DB}.group_owners_bronze (
  ingest_ts TIMESTAMP,
  groupId STRING,
  payload STRING,
  variant STRING
) USING delta
""")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DB}.group_owners_silver (
  groupId STRING,
  ownerId STRING,
  ownerType STRING,
  deleted BOOLEAN,
  raw_ingest_ts TIMESTAMP,
  _source STRING,
  PRIMARY KEY (groupId, ownerId) NOT ENFORCED
) USING delta
""")

OWNERS_TMPL = f"{GRAPH_RESOURCE}/{GRAPH_VERSION}/groups/{{gid}}/owners"

def write_owners_bronze(gid, items):
    if not items:
        return
    rows = [(datetime.now(timezone.utc), gid, json.dumps(x), "upsert") for x in items]
    spark.createDataFrame(rows, "ingest_ts timestamp, groupId string, payload string, variant string").write.mode("append").saveAsTable(f"{DB}.group_owners_bronze")

def silver_from_bronze():
    raw = spark.table(f"{DB}.group_owners_bronze")
    df = spark.read.json(raw.select("payload").rdd.map(lambda r: r[0]))\
        .withColumnRenamed("id","ownerId")\
        .withColumn("ownerType", F.coalesce(F.col("@odata.type"), F.lit("unknown")))
    enriched = raw.select("groupId","ingest_ts").withColumnRenamed("ingest_ts","raw_ingest_ts").join(df, how="inner")\
        .select("groupId","ownerId","ownerType", F.lit(False).alias("deleted"), "raw_ingest_ts")\
        .withColumn("_source", F.lit("owners_list"))
    enriched.createOrReplaceTempView("_o_up")
    spark.sql(f"""
    MERGE INTO {DB}.group_owners_silver t
    USING _o_up s
    ON t.groupId = s.groupId AND t.ownerId = s.ownerId
    WHEN MATCHED THEN UPDATE SET t.ownerType=s.ownerType, t.deleted=False, t.raw_ingest_ts=s.raw_ingest_ts, t._source=s._source
    WHEN NOT MATCHED THEN INSERT *
    """)

def refresh_group(gid: str):
    scope = f"owners:{gid}"
    url = OWNERS_TMPL.format(gid=gid)
    upsert_token(scope, provisional=url, status="in_progress")

    owners = []
    page = url
    while True:
        r = graph_get(page)
        data = r.json()
        owners.extend(data.get('value', []))
        next_link = data.get('@odata.nextLink')
        if next_link:
            page = next_link
        else:
            break

    write_owners_bronze(gid, owners)
    silver_from_bronze()

    ids = [o.get('id') for o in owners if o.get('id')]
    if ids:
        id_list = ",".join([f"'{x}'" for x in ids])
        spark.sql(f"""
        UPDATE {DB}.group_owners_silver
        SET deleted = CASE WHEN ownerId NOT IN ({id_list}) THEN True ELSE False END,
            raw_ingest_ts = current_timestamp(), _source = 'owners_list'
        WHERE groupId = '{gid}'
        """)
    else:
        spark.sql(f"UPDATE {DB}.group_owners_silver SET deleted=True, raw_ingest_ts=current_timestamp(), _source='owners_list' WHERE groupId='{gid}'")

    upsert_token(scope, token=url, provisional="", status="committed")
    audit_scope(RUN_ID, scope, "done", metrics={"owners":str(len(ids)) if ids else "0"})

# Determine groups
changed = [r[0] for r in spark.sql(f"SELECT DISTINCT id FROM {DB}.groups_silver WHERE date(raw_ingest_ts) >= date_sub(current_date(),1)").collect()]
if MODE == "full" or not changed:
    changed = [r[0] for r in spark.sql(f"SELECT id FROM {DB}.groups_silver WHERE deletedDateTime IS NULL").collect()]

# Fan-out
try:
    audit_run_start("owners", MODE, RUN_ID)
    with ThreadPoolExecutor(max_workers=MAX_PARALLEL) as ex:
        futs = {ex.submit(refresh_group, gid): gid for gid in changed}
        for f in as_completed(futs):
            gid = futs[f]
            try:
                f.result()
            except Exception as e:
                audit_scope(RUN_ID, f"owners:{gid}", "error", info=str(e))
                continue
    audit_run_end(RUN_ID, "success", metrics={"groups":str(len(changed))})
except Exception as e:
    audit_run_end(RUN_ID, "failed", details=str(e))
    raise

# KPIs
spark.sql(f"SELECT count(*) AS owners_edges FROM {DB}.group_owners_silver").display()
spark.sql(f"SELECT * FROM {DB}.audit_runs WHERE job='owners' ORDER BY started_at DESC LIMIT 20").display()
