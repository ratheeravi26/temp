# Databricks notebook source
# MAGIC %md
# MAGIC # 01_groups — `/groups/delta` (Unity Catalog + robust failure handling)

# COMMAND ----------
%run ./00_shared_utils

# COMMAND ----------
from datetime import datetime, timezone
import json

# Widgets
try:
    dbutils.widgets.dropdown("mode", "delta", ["full","delta"])
    dbutils.widgets.text("max_parallel", "32")
    dbutils.widgets.text("run_id", f"groups-{int(datetime.now().timestamp())}")
except Exception:
    pass

MODE = dbutils.widgets.get("mode") if 'dbutils' in globals() else "delta"
RUN_ID = dbutils.widgets.get("run_id") if 'dbutils' in globals() else f"groups-{int(datetime.now().timestamp())}"
DB = f"{UC_CATALOG}.{UC_SCHEMA}"

# Storage tables
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DB}.groups_bronze (
  ingest_ts TIMESTAMP,
  payload STRING
) USING delta
""")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DB}.groups_silver (
  id STRING,
  displayName STRING,
  mail STRING,
  mailEnabled BOOLEAN,
  mailNickname STRING,
  securityEnabled BOOLEAN,
  groupTypes ARRAY<STRING>,
  createdDateTime TIMESTAMP,
  deletedDateTime TIMESTAMP,
  renewalDateTime TIMESTAMP,
  description STRING,
  visibility STRING,
  onPremisesSyncEnabled BOOLEAN,
  raw_variant STRING,
  raw_ingest_ts TIMESTAMP,
  _source STRING,
  PRIMARY KEY (id) NOT ENFORCED
) USING delta
""")

# COMMAND ----------
GROUPS_DELTA_URL = f"{GRAPH_RESOURCE}/{GRAPH_VERSION}/groups/delta"

def write_groups_bronze(items):
    rows = [(datetime.now(timezone.utc), json.dumps(x)) for x in items]
    if not rows:
        return
    df = spark.createDataFrame(rows, "ingest_ts timestamp, payload string")
    df.write.mode("append").saveAsTable(f"{DB}.groups_bronze")

def silver_groups_from_bronze():
    raw = spark.table(f"{DB}.groups_bronze")
    df = spark.read.json(raw.select("payload").rdd.map(lambda r: r[0]))
    df = df.withColumn("raw_variant", (df["@removed"].isNotNull()).cast("string")).fillna({"raw_variant":"upsert"})
    df = df.selectExpr(
        "id",
        "displayName",
        "mail",
        "boolean(mailEnabled) as mailEnabled",
        "mailNickname",
        "boolean(securityEnabled) as securityEnabled",
        "groupTypes",
        "timestamp(createdDateTime) as createdDateTime",
        "timestamp(deletedDateTime) as deletedDateTime",
        "timestamp(renewedDateTime) as renewalDateTime",
        "description",
        "visibility",
        "boolean(onPremisesSyncEnabled) as onPremisesSyncEnabled",
        "raw_variant",
        "current_timestamp() as raw_ingest_ts",
        "'groups_delta' as _source"
    )
    df.createOrReplaceTempView("_g_up")
    spark.sql(f"""
    MERGE INTO {DB}.groups_silver t
    USING _g_up s
    ON t.id = s.id
    WHEN MATCHED THEN UPDATE SET *
    WHEN NOT MATCHED THEN INSERT *
    """)

def run_groups_delta():
    scope = "groups"
    token, status, provisional = get_token(scope)
    url = GROUPS_DELTA_URL if not token else token

    upsert_token(scope, provisional=url, status="in_progress")
    page = 0
    total = 0

    while True:
        audit_scope(RUN_ID, scope, "fetch", f"page {page}")
        r = graph_get(url)
        data = r.json()
        items = data.get('value', [])
        total += len(items)
        write_groups_bronze(items)
        next_link = data.get('@odata.nextLink')
        delta_link = data.get('@odata.deltaLink')
        if next_link:
            url = next_link
            page += 1
        else:
            silver_groups_from_bronze()
            if delta_link:
                upsert_token(scope, token=delta_link, provisional="", status="committed")
            audit_scope(RUN_ID, scope, "done", metrics={"pages":str(page+1), "items":str(total)})
            break

# COMMAND ----------
# Entry
try:
    audit_run_start("groups", MODE, RUN_ID)
    run_groups_delta()
    audit_run_end(RUN_ID, "success")
except Exception as e:
    audit_run_end(RUN_ID, "failed", details=str(e))
    raise

# COMMAND ----------
# KPIs
spark.sql(f"SELECT count(*) as groups_total FROM {DB}.groups_silver").display()
spark.sql(f"SELECT * FROM {DB}.control_delta_tokens WHERE scope='groups'").display()
spark.sql(f"SELECT * FROM {DB}.audit_runs WHERE job='groups' ORDER BY started_at DESC LIMIT 20").display()
