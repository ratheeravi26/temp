# Databricks notebook source
# MAGIC %md
# MAGIC # 02_members — `/groups/{id}/members/delta` (Unity Catalog)

# COMMAND ----------
%run ./00_shared_utils

# COMMAND ----------
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from pyspark.sql import functions as F

try:
    dbutils.widgets.text("max_parallel", "48")
    dbutils.widgets.text("run_id", "members-0")
    dbutils.widgets.text("mode", "delta")
except Exception:
    pass

MAX_PARALLEL = int(dbutils.widgets.get("max_parallel")) if 'dbutils' in globals() else 48
RUN_ID = dbutils.widgets.get("run_id") if 'dbutils' in globals() else f"members-{int(datetime.now().timestamp())}"
MODE = dbutils.widgets.get("mode") if 'dbutils' in globals() else "delta"
DB = f"{UC_CATALOG}.{UC_SCHEMA}"

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DB}.group_members_bronze (
  ingest_ts TIMESTAMP,
  groupId STRING,
  payload STRING,
  variant STRING
) USING delta
""")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DB}.group_members_silver (
  groupId STRING,
  memberId STRING,
  memberType STRING,
  deleted BOOLEAN,
  raw_ingest_ts TIMESTAMP,
  _source STRING,
  PRIMARY KEY (groupId, memberId) NOT ENFORCED
) USING delta
""")

MEMBERS_DELTA_TMPL = f"{GRAPH_RESOURCE}/{GRAPH_VERSION}/groups/{{gid}}/members/delta"

def write_members_bronze(gid, rows, variant):
    if not rows:
        return
    out = [(datetime.now(timezone.utc), gid, json.dumps(x), variant) for x in rows]
    spark.createDataFrame(out, "ingest_ts timestamp, groupId string, payload string, variant string").write.mode("append").saveAsTable(f"{DB}.group_members_bronze")

def silver_from_bronze():
    raw = spark.table(f"{DB}.group_members_bronze")
    df = spark.read.json(raw.select("payload").rdd.map(lambda r: r[0]))\
        .withColumnRenamed("id","memberId")\
        .withColumn("memberType", F.coalesce(F.col("@odata.type"), F.lit("unknown")))
    enriched = raw.select("groupId","ingest_ts").withColumnRenamed("ingest_ts","raw_ingest_ts").join(df, how="inner")\
        .select("groupId","memberId","memberType", F.lit(False).alias("deleted"), "raw_ingest_ts")\
        .withColumn("_source", F.lit("members_delta"))
    enriched.createOrReplaceTempView("_m_up")
    spark.sql(f"""
    MERGE INTO {DB}.group_members_silver t
    USING _m_up s
    ON t.groupId = s.groupId AND t.memberId = s.memberId
    WHEN MATCHED THEN UPDATE SET t.memberType=s.memberType, t.deleted=False, t.raw_ingest_ts=s.raw_ingest_ts, t._source=s._source
    WHEN NOT MATCHED THEN INSERT *
    """)

def process_group(gid: str):
    scope = f"members:{gid}"
    token, status, provisional = get_token(scope)
    url = MEMBERS_DELTA_TMPL.format(gid=gid) if not token else token
    upsert_token(scope, provisional=url, status="in_progress")
    total = 0
    while True:
        r = graph_get(url)
        data = r.json()
        items = data.get('value', [])
        upserts = [x for x in items if "@removed" not in x]
        tombs = [x for x in items if "@removed" in x]
        write_members_bronze(gid, upserts, "upsert")
        write_members_bronze(gid, tombs, "tombstone")
        total += len(items)
        next_link = data.get('@odata.nextLink')
        delta_link = data.get('@odata.deltaLink')
        if next_link:
            url = next_link
        else:
            silver_from_bronze()
            if delta_link:
                upsert_token(scope, token=delta_link, provisional="", status="committed")
            audit_scope(RUN_ID, scope, "done", metrics={"items":str(total)})
            break

# Determine groups
changed = [r[0] for r in spark.sql(f"SELECT DISTINCT id FROM {DB}.groups_silver WHERE date(raw_ingest_ts) >= date_sub(current_date(),1)").collect()]
if MODE == "full" or not changed:
    changed = [r[0] for r in spark.sql(f"SELECT id FROM {DB}.groups_silver WHERE deletedDateTime IS NULL").collect()]

# Fan-out
try:
    audit_run_start("members", MODE, RUN_ID)
    with ThreadPoolExecutor(max_workers=MAX_PARALLEL) as ex:
        futs = {ex.submit(process_group, gid): gid for gid in changed}
        for f in as_completed(futs):
            gid = futs[f]
            try:
                f.result()
            except Exception as e:
                audit_scope(RUN_ID, f"members:{gid}", "error", info=str(e))
                continue
    audit_run_end(RUN_ID, "success", metrics={"groups":str(len(changed))})
except Exception as e:
    audit_run_end(RUN_ID, "failed", details=str(e))
    raise

# KPIs
spark.sql(f"SELECT count(*) AS membership_edges FROM {DB}.group_members_silver").display()
spark.sql(f"SELECT * FROM {DB}.audit_runs WHERE job='members' ORDER BY started_at DESC LIMIT 20").display()
