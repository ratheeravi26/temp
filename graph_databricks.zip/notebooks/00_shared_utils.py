# Databricks notebook source
# MAGIC %md
# MAGIC # 00_shared_utils — Microsoft Graph helpers, Delta token store, audit logging (Unity Catalog)

# COMMAND ----------
# Widgets
try:
    dbutils.widgets.text("uc_catalog", "ubs_platform")
    dbutils.widgets.text("uc_schema", "id_graph")
    dbutils.widgets.text("secret_scope", "graph")
    dbutils.widgets.text("request_timeout_sec", "60")
except Exception:
    pass

UC_CATALOG = dbutils.widgets.get("uc_catalog") if 'dbutils' in globals() else "ubs_platform"
UC_SCHEMA = dbutils.widgets.get("uc_schema") if 'dbutils' in globals() else "id_graph"
SECRET_SCOPE = dbutils.widgets.get("secret_scope") if 'dbutils' in globals() else "graph"
REQUEST_TIMEOUT = int(dbutils.widgets.get("request_timeout_sec")) if 'dbutils' in globals() else 60

DB = f"{UC_CATALOG}.{UC_SCHEMA}"

# Secrets
TENANT_ID = dbutils.secrets.get(SECRET_SCOPE, "TENANT_ID")
CLIENT_ID = dbutils.secrets.get(SECRET_SCOPE, "CLIENT_ID")
CLIENT_SECRET = dbutils.secrets.get(SECRET_SCOPE, "CLIENT_SECRET")

# Graph endpoints
GRAPH_RESOURCE = "https://graph.microsoft.com"
GRAPH_VERSION = "v1.0"
TOKEN_URL = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
SCOPE = "https://graph.microsoft.com/.default"

# COMMAND ----------
# Create control & audit tables (Unity Catalog)
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {UC_CATALOG}.{UC_SCHEMA}")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DB}.control_delta_tokens (
  scope STRING,
  token STRING,
  status STRING,
  provisional_token STRING,
  updated_at TIMESTAMP,
  extra MAP<STRING,STRING>,
  PRIMARY KEY (scope) NOT ENFORCED
) USING delta
""")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DB}.audit_runs (
  run_id STRING,
  job STRING,
  mode STRING,
  started_at TIMESTAMP,
  ended_at TIMESTAMP,
  status STRING,
  details STRING,
  metrics MAP<STRING,STRING>
) USING delta
""")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DB}.audit_scopes (
  run_id STRING,
  scope STRING,
  stage STRING,
  ts TIMESTAMP,
  info STRING,
  metrics MAP<STRING,STRING>
) USING delta
""")

# COMMAND ----------
# Auth + HTTP helpers with retry & backoff
import time, json
import requests
from requests.exceptions import RequestException

_session = requests.Session()
_access_token = None
_access_token_exp = 0

def _get_access_token() -> str:
    data = {
        'client_id': CLIENT_ID,
        'client_secret': CLIENT_SECRET,
        'grant_type': 'client_credentials',
        'scope': SCOPE,
    }
    r = _session.post(TOKEN_URL, data=data, timeout=REQUEST_TIMEOUT)
    r.raise_for_status()
    return r.json()['access_token']

def auth_header():
    global _access_token, _access_token_exp
    now = time.time()
    if not _access_token or now >= _access_token_exp:
        _access_token = _get_access_token()
        _access_token_exp = now + 3000  # ~50 minutes
    return {"Authorization": f"Bearer {_access_token}"}

def graph_get(url: str, params: dict | None = None, max_retries: int = 8) -> requests.Response:
    backoff = 1.0
    for _ in range(max_retries):
        try:
            r = _session.get(url, params=params, headers={**auth_header(), "ConsistencyLevel":"eventual"}, timeout=REQUEST_TIMEOUT)
            if r.status_code in (429,503,504):
                retry_after = int(r.headers.get("Retry-After", backoff))
                time.sleep(retry_after)
                backoff = min(backoff*2, 60)
                continue
            r.raise_for_status()
            return r
        except RequestException:
            time.sleep(backoff)
            backoff = min(backoff*2, 60)
    r = _session.get(url, params=params, headers=auth_header(), timeout=REQUEST_TIMEOUT)
    r.raise_for_status()
    return r

# COMMAND ----------
# Token helpers + audit
from datetime import datetime, timezone

def upsert_token(scope: str, token: str | None = None, provisional: str | None = None, status: str = "committed", extra: dict | None = None):
    token = token or ""
    provisional = provisional or ""
    spark.sql(f"""
        MERGE INTO {DB}.control_delta_tokens t
        USING (SELECT '{scope}' AS scope) s
        ON t.scope = s.scope
        WHEN MATCHED THEN UPDATE SET
          t.token = CASE WHEN '{status}'='committed' THEN '{token}' ELSE t.token END,
          t.status = '{status}',
          t.provisional_token = '{provisional}',
          t.updated_at = current_timestamp(),
          t.extra = t.extra
        WHEN NOT MATCHED THEN INSERT (scope, token, status, provisional_token, updated_at, extra)
          VALUES ('{scope}', '{token}', '{status}', '{provisional}', current_timestamp(), map())
    """)

def get_token(scope: str):
    rows = spark.sql(f"SELECT token, status, provisional_token FROM {DB}.control_delta_tokens WHERE scope = '{scope}'").limit(1).collect()
    if rows:
        r = rows[0]
        return r[0], r[1], r[2]
    return None, None, None

def audit_run_start(job: str, mode: str, run_id: str):
    spark.sql(f"""
        INSERT INTO {DB}.audit_runs VALUES ('{run_id}','{job}','{mode}', current_timestamp(), NULL, 'running', NULL, map())
    """)

def audit_run_end(run_id: str, status: str, details: str = "", metrics: dict | None = None):
    details = details.replace("'", "\'")
    metrics = metrics or {}
    pairs = ",".join([f"'{k}','{v}'" for k,v in metrics.items()])
    spark.sql(f"""
        UPDATE {DB}.audit_runs SET ended_at = current_timestamp(), status = '{status}', details = '{details}', metrics = map({pairs})
        WHERE run_id = '{run_id}'
    """)

def audit_scope(run_id: str, scope: str, stage: str, info: str = "", metrics: dict | None = None):
    metrics = metrics or {}
    pairs = ",".join([f"'{k}','{v}'" for k,v in metrics.items()])
    spark.sql(f"""
        INSERT INTO {DB}.audit_scopes VALUES ('{run_id}','{scope}','{stage}', current_timestamp(), '{info}', map({pairs}))
    """)
