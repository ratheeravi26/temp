# Databricks notebook source
# MAGIC %md
# MAGIC # 04_users — `/users/delta` (Unity Catalog) for dimension/enrichment

# COMMAND ----------
%run ./00_shared_utils

# COMMAND ----------
from datetime import datetime, timezone
import json

try:
    dbutils.widgets.text("mode", "delta")
    dbutils.widgets.text("run_id", "users-0")
except Exception:
    pass

MODE = dbutils.widgets.get("mode") if 'dbutils' in globals() else "delta"
RUN_ID = dbutils.widgets.get("run_id") if 'dbutils' in globals() else f"users-{int(datetime.now().timestamp())}"
DB = f"{UC_CATALOG}.{UC_SCHEMA}"

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DB}.users_bronze (
  ingest_ts TIMESTAMP,
  payload STRING
) USING delta
""")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DB}.users_silver (
  id STRING,
  userPrincipalName STRING,
  displayName STRING,
  mail STRING,
  givenName STRING,
  surname STRING,
  jobTitle STRING,
  department STRING,
  accountEnabled BOOLEAN,
  createdDateTime TIMESTAMP,
  deletedDateTime TIMESTAMP,
  onPremisesSamAccountName STRING,
  raw_variant STRING,
  raw_ingest_ts TIMESTAMP,
  _source STRING,
  PRIMARY KEY (id) NOT ENFORCED
) USING delta
""")

USERS_DELTA_URL = f"{GRAPH_RESOURCE}/{GRAPH_VERSION}/users/delta"

def write_bronze(items):
    rows = [(datetime.now(timezone.utc), json.dumps(x)) for x in items]
    if rows:
        spark.createDataFrame(rows, "ingest_ts timestamp, payload string").write.mode("append").saveAsTable(f"{DB}.users_bronze")

def silver_from_bronze():
    raw = spark.table(f"{DB}.users_bronze")
    df = spark.read.json(raw.select("payload").rdd.map(lambda r: r[0]))
    df = df.withColumn("raw_variant", (df["@removed"].isNotNull()).cast("string")).fillna({"raw_variant":"upsert"})
    df = df.selectExpr(
        "id",
        "userPrincipalName",
        "displayName",
        "mail",
        "givenName",
        "surname",
        "jobTitle",
        "department",
        "boolean(accountEnabled) as accountEnabled",
        "timestamp(createdDateTime) as createdDateTime",
        "timestamp(deletedDateTime) as deletedDateTime",
        "onPremisesSamAccountName",
        "raw_variant",
        "current_timestamp() as raw_ingest_ts",
        "'users_delta' as _source"
    )
    df.createOrReplaceTempView("_u_up")
    spark.sql(f"""
    MERGE INTO {DB}.users_silver t
    USING _u_up s
    ON t.id = s.id
    WHEN MATCHED THEN UPDATE SET *
    WHEN NOT MATCHED THEN INSERT *
    """)

def run_users_delta():
    scope = "users"
    token, status, provisional = get_token(scope)
    url = USERS_DELTA_URL if not token else token
    upsert_token(scope, provisional=url, status="in_progress")
    page = 0
    total = 0
    while True:
        r = graph_get(url)
        data = r.json()
        items = data.get('value', [])
        total += len(items)
        write_bronze(items)
        next_link = data.get('@odata.nextLink')
        delta_link = data.get('@odata.deltaLink')
        if next_link:
            url = next_link
            page += 1
        else:
            silver_from_bronze()
            if delta_link:
                upsert_token(scope, token=delta_link, provisional="", status="committed")
            break

# Entry
try:
    audit_run_start("users", MODE, RUN_ID)
    run_users_delta()
    audit_run_end(RUN_ID, "success")
except Exception as e:
    audit_run_end(RUN_ID, "failed", details=str(e))
    raise

# KPIs
spark.sql(f"SELECT count(*) AS users FROM {DB}.users_silver").display()
spark.sql(f"SELECT * FROM {DB}.control_delta_tokens WHERE scope='users'").display()
