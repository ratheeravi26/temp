-- Unity Catalog views for analytics
-- Set your catalog & schema first if running in a SQL warehouse:
-- USE CATALOG ubs_platform;
-- USE SCHEMA id_graph;

CREATE OR REPLACE VIEW users_v AS
SELECT id, userPrincipalName, displayName, mail, givenName, surname, jobTitle, department, accountEnabled
FROM users_silver
WHERE coalesce(deletedDateTime, TIMESTAMP('9999-12-31')) = TIMESTAMP('9999-12-31');

CREATE OR REPLACE VIEW groups_v AS
SELECT id, displayName, mail, mailEnabled, securityEnabled, groupTypes, createdDateTime, visibility
FROM groups_silver
WHERE deletedDateTime IS NULL;

CREATE OR REPLACE VIEW group_members_v AS
SELECT m.groupId,
       g.displayName AS groupName,
       m.memberId,
       u.displayName AS memberName,
       u.userPrincipalName AS memberUPN,
       m.memberType,
       m.deleted
FROM group_members_silver m
LEFT JOIN groups_silver g ON g.id = m.groupId
LEFT JOIN users_silver u ON u.id = m.memberId;

CREATE OR REPLACE VIEW group_owners_v AS
SELECT o.groupId,
       g.displayName AS groupName,
       o.ownerId,
       u.displayName AS ownerName,
       u.userPrincipalName AS ownerUPN,
       o.ownerType,
       o.deleted
FROM group_owners_silver o
LEFT JOIN groups_silver g ON g.id = o.groupId
LEFT JOIN users_silver u ON u.id = o.ownerId;

CREATE OR REPLACE VIEW group_membership_flat AS
SELECT g.displayName AS groupName,
       u.displayName AS userName,
       u.userPrincipalName AS upn,
       u.department,
       u.jobTitle
FROM group_members_silver m
JOIN users_silver u ON u.id = m.memberId
JOIN groups_silver g ON g.id = m.groupId
WHERE m.deleted = false AND g.deletedDateTime IS NULL;
